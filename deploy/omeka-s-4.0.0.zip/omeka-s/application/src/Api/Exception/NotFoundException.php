<?php
namespace Omeka\Api\Exception;

class NotFoundException extends BadRequestException
{
}
