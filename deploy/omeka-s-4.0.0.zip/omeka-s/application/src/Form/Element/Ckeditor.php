<?php
namespace Omeka\Form\Element;

class Ckeditor extends HtmlTextarea
{
    protected $attributes = [
        'type' => 'ckeditor',
    ];
}
